#include"kernel/types.h"
#include"user/user.h"

int main()
{
  malloc_test();
  return 0;
}
