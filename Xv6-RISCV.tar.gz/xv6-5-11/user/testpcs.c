#include"kernel/types.h"
#include"user/user.h"

int main()
{
  getpcs();
  return 0;
}
