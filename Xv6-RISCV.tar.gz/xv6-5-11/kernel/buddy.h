//伙伴系统，最小单元为 8 Byte。
#include "math.h"
#include "memlayout.h"
#include "defs.h"
#include "types.h"
#define SIZE 8*1024*1024 //总字节数
struct buddy {
  struct spinlock lock;
  unsigned size;//可分配的单元数，按8byte一单元
  uint8 longest[2*1024*1024-1];
  unsigned capacity;
}self;

#define IS_POWER_OF_2(x) (!((x)&((x)-1)))//判断2次幂函数
#define MAX(a, b) ((a) > (b) ? (a) : (b))//取最大
unsigned fixsize(unsigned size) {//将当前size向上对齐为2次幂
  size |= size >> 1;
  size |= size >> 2;
  size |= size >> 4;
  size |= size >> 8;
  size |= size >> 16;
  return size + 1;
}
inline unsigned left_leaf(unsigned index) {//左子树索引
    return index * 2 + 1;
}
inline unsigned right_leaf(unsigned index) {//右子树索引
    return index * 2 + 2;
}
inline unsigned parent(unsigned index) {//父结点索引
    return (index + 1) / 2 - 1;
}

//struct buddy* buddy_new(int size) {//初始化，size为总共可分配的Byte数。需化为8 Byte单位
    // struct buddy* self_p;
    // struct buddy self;
    // self.capacity = 0;
    // self.size = 0;
    // self_p = &self;
void buddy_new(int size){//参数size是总共分配的字节数
    unsigned node_size;//节点的个数
    unsigned fake_node_size;
    int i;
    if (size < 1 || !IS_POWER_OF_2(size)) {
        panic("buddy_new error!");
    }
    initlock(&self.lock,"selflock");
    //freerange((void*)HEAPBASE,(void*)HEAPTOP);
    printf("本次实验空间：%p 到 %p\n",HEAPBASE ,HEAPTOP);
    //单位化为8 Byte.
    if(size<USIZE)
    {
        size = 1;
    }
    else
    {
        size/=USIZE;
    }
    self.size = size;//这里的size已经变成了单元数。
    node_size = size * 2;//结点个数
    fake_node_size = node_size * 2;
    self.capacity = USIZE*size;//容量仍然以字节为单位存储。
    // 遍历每个二叉树结点，为其赋值
    for (i = 0; i < 2 * size - 1; ++i) {
        if (IS_POWER_OF_2(i + 1)) {
            node_size /= 2;
            fake_node_size  = node_size * 2;//为了log值上移1。
        }
        // 第一层的结点的值是2*size，第二层是size，第三次是size/2，以此类推
        // 每个值代表的是空闲内存块的数量
        self.longest[i] = log_2(fake_node_size);//用log2来存储，减少了存储空间。notice that this is the fake one
    }
    printf("successfully init a new buddy!\n");
}


void* buddy_alloc(uint64 space) {//分配函数，space是所需大小，单位为Byte，要转换到8 BYte
    unsigned index = 0;
    unsigned node_size;
    unsigned offset = 0;
    unsigned temp;//用来存储
    uint64   fake_space;
    
    if(!IS_POWER_OF_2(space)) {
        space = fixsize(space); // 向上调整到2的幂次
    }
    // 将单位化为8Byte。
    space = (space + USIZE -1) / USIZE;//用到的单元数
    fake_space = 2 * space;
    // 将 fake_space 对数化，以匹配与longest数组的比较。
    space = log_2(space);
    fake_space = log_2(fake_space);

    // 如果根节点下挂的space都不够分配，就返回失败
    if(self.longest[index] < fake_space) {
        panic("error: no enough memory!\n");
        return 0;
    }
    acquire(&self.lock);
    // 由大到小搜索最符合space的结点
    // 并在搜索的过程中，更新index，优先使用左孩子
    for(node_size = self.size; log_2(node_size) != space; node_size /= 2) {
        if(self.longest[left_leaf(index)] >= fake_space ) {
            index = left_leaf(index);
        } else {
            index = right_leaf(index);//非左即右
        }
    }
    temp = USIZE*exp_2(space);//存储本次分配所用到的内存字节。
    self.capacity -= temp;
    // 找到对应的结点了，就将其管理的空闲内存块数量标记为 0
    self.longest[index] = 0;
    
    // 这里的node_size是对应层的结点所管理的内存的大小，而index是结点的编号
    // 根据这个算法，offset恰好是分配内存的起始/索引，从offset往后数8*space个字节的内存都是可用的
    offset = USIZE*((index + 1) * node_size - self.size);
    printf("分配大小为%d字节的地址,分配地址范围是：%p——%p,剩余容量为%p\n",
        temp,HEAPBASE+offset,HEAPBASE+offset+temp,self.capacity);

    printf("分配的块号是：%d 到 %d 块\n\n", offset/USIZE, (offset+temp)/USIZE - 1);//显示所用的块数
    
    // 因为更新了longest[index]的标记，所以需要更新它上层所有父节点的标记
    while(index) {
        index = parent(index);
        self.longest[index] = MAX(self.longest[left_leaf(index)],
                                   self.longest[right_leaf(index)]);
    }
    void *p = (void*)(HEAPBASE+offset);
    //memset(p, 5 ,temp);// 将所需分配的地址填满5,junk

    release(&self.lock);        
    return p;
}

void buddy_free(void* pa) {
    unsigned node_size, fake_node_size, index = 0;
    unsigned left_longest, right_longest;
    node_size = 1;
    index = ((uint64)pa-HEAPBASE)/USIZE + self.size - 1;
    acquire(&self.lock);
    // 找到被占用的那个内存块，并更新node_size，即那层的结点所管理的内存块的大小
    for(; self.longest[index] != 0; index = parent(index)) {
        node_size *= 2;
        // 如果根节点的都被占用了，则直接返回
        if(index == 0) {
            memset((void*)HEAPBASE , 1 ,  node_size);
        }
    }
    fake_node_size = 2 * node_size;
    // 归还内存，将longest恢复到原来结点的值
    //memset(pa, 1 ,node_size);
    self.longest[index] = log_2(fake_node_size);
    self.capacity += USIZE*exp_2(self.longest[index]-1);
    printf("恢复%p 到 %p 的内存\n\n",(uint64)pa, (uint64)pa + node_size*USIZE);
    printf("回收的块号：%d 到 %d块\n",((uint64)pa - HEAPBASE)/USIZE ,  ((uint64)pa - HEAPBASE + node_size*USIZE)/USIZE - 1);
    
    // 接下来恢复被占用结点的所有父节点
    while(index) {
        index = parent(index);
        node_size *= 2;
        
        // 在向上回溯的过程中，如果发现左右孩子的元素加起来等于自己，则说明需要合并
        // 否则取他们中大的那个
        left_longest = self.longest[left_leaf(index)];
        right_longest = self.longest[right_leaf(index)];
        
        if(left_longest + right_longest == log_2(fake_node_size)) 
        {
             self.longest[index] = log_2(fake_node_size);
        } else {
            self.longest[index] = MAX(left_longest, right_longest);
        }
    }
    release(&self.lock);
}