unsigned 
log_2(int a)
{
  int cnt = 0;
  while(a != 1)
  {
    a/=2;
    cnt++;
  }
  return cnt;
}

unsigned
exp_2(int a)
{
  int h = 1;
  if(a == 0)
  {
    return h;
  }
  else{
  for(int i = 0; i < a; i++)
  {
    h*=2;
  }
  return h;
  }
}